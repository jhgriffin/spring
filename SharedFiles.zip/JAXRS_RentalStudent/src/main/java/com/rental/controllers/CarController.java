package com.rental.controllers;

import com.rental.RentalProperties;
import com.rental.dao.RentalCar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.rental.dao.CarService;

import javax.ws.rs.*;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;


//TODO
public class CarController{
	
	@Autowired
	private CarService dao;
    @Autowired
	private RentalProperties props;

	//TODO
	public RentalCar getById(long id){
		RentalCar car =  dao.getByID(id);
		RentalProperties.Airport airport = props.getAirports()
				.stream()
				.filter(p-> p.getIataCode().equals(car.getLocation()))
				.findFirst().get();
		double tax = car.getDailyRate() * airport.getTax()/100;
		car.setDailyRate(car.getDailyRate() + tax);
		return car;
	}

	//TODO
	public Collection<RentalCar> get(String str){
		return  dao.getAll().stream()
				.filter(p-> p.getLocation().equals(str))
				.collect(Collectors.toList());
	}

}
