package com.rental;


import com.rental.dao.CarService;

import com.rental.dao.RentalCar;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;


import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.web.reactive.function.BodyInserters.fromObject;

public class RentalCarHandler {

    @Autowired
    private CarService dao;

    //http://localhost:8088/4
    public Mono<ServerResponse> get(ServerRequest request) {
        long id = Long.valueOf(request.pathVariable("id"));
        RentalCar car = dao.getByID(id);
        return ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(fromObject(car));
    }

    public Mono<ServerResponse> getAll(ServerRequest request) {
         Collection<RentalCar> cars = dao.getAll();
        return ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(fromObject(cars));
    }


    public Mono<ServerResponse> getByLocationAndPrice(ServerRequest request) {
        Collection<RentalCar> cars = dao.getAll();
        String pickUp =request.pathVariable("pickUp");
        double price = Double.valueOf(request.pathVariable("price"));
        List<RentalCar> list =cars.stream()
                .filter(p-> p.getLocation().equals(pickUp) &&
                p.getDailyRate() < price).collect(Collectors.toList());
        return ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(fromObject(list));
    }
}
