package com.rental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.annotation.Bean;

import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;


@SpringBootApplication
 public class RepoApplication {

    public static void main(String[] args){
        SpringApplication app = new SpringApplication (RepoApplication.class);
        app.run(args);
    }

    @Bean
    public RouterFunction<ServerResponse> routingFunction() {
        return RouterFunctions.route(
                GET("/{id}"), handler()::getAll)
                .andRoute(GET("/{pickUp}/{price:.+}"), handler()::getByLocationAndPrice)
                .andRoute(GET("/"), handler()::getAll);
    }

    @Bean
    public RentalCarHandler handler() {
        return new RentalCarHandler();
    }
}
